<?php //include('config.php'); ?>
<?php session_start();include('db_connection.php'); ?>
<?php 
						date_default_timezone_set('Asia/Kolkata');

						$client = $_POST['client'];
	   
       $banks = explode(",",$_SESSION['bankname']);
       $_bank_name = [];
       for($i=0;$i<count($banks);$i++){
		   $_bank = explode("_",$banks[$i]);
		   if($_bank[0]==$client){
			   array_push($_bank_name,$_bank[1]);
		   }
	   } 
	    $_bank_name=json_encode($_bank_name);
		$_bank_name=str_replace( array('[',']','"') , ''  , $_bank_name);
		$bankarr=explode(',',$_bank_name);
		$_bank_name = "'" . implode ( "', '", $bankarr )."'";
		
						$bank = $_POST['bank'];
						$atmid = $_POST['atmid'];
						$month = $_POST['month'];
						$year = $_POST['year'];
						if($month<10){
							$mon = "0".$month;
						}else{
							$mon = $month;
						}
						$query_date = $year."-".$mon."-01";
						//$query_date = '2010-02-04';

						// First day of the month.
						$start = date('Y-m-01', strtotime($query_date));

						// Last day of the month.
						$end = date('Y-m-t', strtotime($query_date));

						$con = OpenCon();

						if($atmid!=''){
							$sql = mysqli_query($con,"select SN,DVRIP,ATMID,SiteAddress from sites where atmid='".$atmid."' and live='Y'");
							$sitesql_result = mysqli_fetch_assoc($sql);
							$dvrip = $sitesql_result['DVRIP'];
						}else{
							if($bank!=''){
							  $sql = mysqli_query($con,"select SN,DVRIP,ATMID,SiteAddress from sites where Customer='".$client."' and Bank='".$bank."' and live='Y'");
							}else{
								$sql = mysqli_query($con,"select SN,DVRIP,ATMID,SiteAddress from sites where Customer='".$client."' and Bank IN (".$_bank_name.") and live='Y'");
							}
							if(mysqli_num_rows($sql)>0){
							while($sitesql_result = mysqli_fetch_assoc($sql)){
								if(!is_null($sitesql_result['DVRIP'])){
									if($sitesql_result['DVRIP']!=''){
									  $atmidarray[] = $sitesql_result['DVRIP'];
									}
								}
							}
							}else{
								$atmidarray = [];
							}
							$atmidarray=json_encode($atmidarray);
							$atmidarray=str_replace( array('[',']','"') , ''  , $atmidarray);
							$arr=explode(',',$atmidarray);
							$atmidarray = "'" . implode ( "', '", $arr )."'";
							/*
							$testsql = "SELECT * FROM dvrcommunicationdetails_test WHERE DVRIP IN (".$atmidarray.")";
							$sql = mysqli_query($con,$sitesql); */
						}
                    $main_actual_arr = [];
						for($i=1;$i<=31;$i++){
								if($i<9){
									$dd = "0".$i;
								}else{
									$dd = $i;
								}
								$query_date = $year."-".$month."-".$dd;
								
								// First day of the month.
								$start = $query_date;

								// Last day of the month.
								$end = $query_date;
								if($atmid!=''){ 
								    $testsql = "SELECT cdate,last_communication,ip FROM dvr_history WHERE ip ='".$dvrip."' AND CAST(cdate AS DATE)>='".$start."' 
													   AND CAST(cdate AS DATE)<='".$end."' AND last_communication IS NOT NULL AND cdate IS NOT NULL ORDER BY cdate DESC LIMIT 1"; 
								}else{
									$testsql = "SELECT cdate,last_communication,ip FROM dvr_history WHERE ip IN (".$atmidarray.") AND CAST(cdate AS DATE)>='".$start."' 
													   AND CAST(cdate AS DATE)<='".$end."' AND last_communication IS NOT NULL AND cdate IS NOT NULL  ORDER BY cdate DESC"; 
								}
											
								$dvrhis_query = mysqli_query($con,$testsql); 
								$dvr_online_count = 0;
								$dvr_offline_count = 0;
								$total_online_percent = 0;
								$totaldvrconnect = mysqli_num_rows($dvrhis_query);   
								if(mysqli_num_rows($dvrhis_query)>0){
									$unique_dvrip = array();
									while($dvr_sql_result = mysqli_fetch_assoc($dvrhis_query)){
										$dvr_ip = $dvr_sql_result['ip'];
										if(!in_array($dvr_ip,$unique_dvrip)){
											array_push($unique_dvrip,$dvr_ip);
											$connect_time = $dvr_sql_result['cdate'];
											$last_com_time = $dvr_sql_result['last_communication'];
											if (!empty($connect_time) && !empty($last_com_time)) {
												$d1 = new DateTime($connect_time);
												$d2 = new DateTime($last_com_time);
												if ($d1 == $d2) { 
												   $dvr_online_count = $dvr_online_count + 1;
												}else{
													$dvr_offline_count = $dvr_offline_count + 1;
												}
												$totaldvrconnect = $dvr_online_count + $dvr_offline_count;
											}
										}
									}
									$number = ($dvr_online_count/$totaldvrconnect)*100;
									$total_online_percent = number_format((float)$number, 2, '.', '');
								}
								$j = $i - 1;
							$dvronlinearray[$j] = $dvr_online_count;
							$dvrofflinearray[$j] = $dvr_offline_count;
							$_status_online_percent[$j] = $total_online_percent; 
							$actual_arr['y'] = strval($i);
							$actual_arr['a'] = $dvr_online_count;	
							$actual_arr['b'] = $dvr_offline_count;	
                            $main_actual_arr[$j] = $actual_arr; 							
						}
											
										
$array = array(['dvr_online_count'=>$dvronlinearray,'dvr_offline_count'=>$dvrofflinearray,'resdata'=>$main_actual_arr,'online_percent'=>$_status_online_percent,'test_sql'=>$testsql]);
CloseCon($con);
echo json_encode($array);
?>


