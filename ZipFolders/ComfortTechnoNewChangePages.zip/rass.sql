-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 15, 2021 at 11:28 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurv`
--

-- --------------------------------------------------------

--
-- Table structure for table `rass`
--

DROP TABLE IF EXISTS `rass`;
CREATE TABLE IF NOT EXISTS `rass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SensorName` varchar(35) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
  `VTASMain` varchar(3) DEFAULT NULL,
  `ZONE` varchar(4) DEFAULT NULL,
  `SCODE` varchar(3) DEFAULT NULL,
  `PRIORITY` varchar(1) DEFAULT NULL,
  `SIACode` varchar(12) DEFAULT NULL,
  `Camera` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ZONE` (`ZONE`,`SCODE`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rass`
--

INSERT INTO `rass` (`id`, `SensorName`, `code`, `VTASMain`, `ZONE`, `SCODE`, `PRIORITY`, `SIACode`, `Camera`) VALUES
(1, 'Lobby PIR Motion sensor', 'NJP001', 'YES', '001', 'JP', 'Y', 'No restroral', 'Lobby Cam'),
(2, 'Glass Break Sensor', 'NBA002', 'YES', '002', 'BA', 'R', 'NBR002', 'Lobby Cam'),
(3, 'Panic Switch', 'NPA003', 'YES', '003', 'PA', 'R', 'NPR003', 'Lobby Cam'),
(4, 'Main Door shutter Normally NO type', 'NBA004', 'YES', '004', 'BA', 'R', 'NBR004', 'Lobby Cam'),
(5, 'ATM1 Removal ', 'NBA005', 'YES', '005', 'BA', 'R', 'NBR005', 'Lobby Cam'),
(6, 'ATM 1 Vibration', 'NDF006', 'YES', '006', 'DF', 'R', 'NDR006', 'Lobby Cam'),
(7, 'ATM2 Removal ', 'NBA007', 'YES', '007', 'BA', 'R', 'NBR007', 'Lobby Cam'),
(8, 'ATM 2 Vibration', 'NDF008', 'YES', '008', 'DF', 'R', 'NDR008', 'Lobby Cam'),
(9, 'ATM 3 Removal ', 'NBA009', 'YES', '009', 'BA', 'R', 'NBR009', 'Lobby Cam'),
(10, 'ATM 3 Vibration', 'NDF010', 'YES', '010', 'DF', 'R', 'NDR010', 'Lobby Cam'),
(11, 'Smoke Detector 12V IN +', 'NFA011', 'YES', '011', 'FA', 'R', 'NFR011', 'Lobby Cam'),
(12, 'Video loss/Video temper/HDD alarm', 'NBA028', 'YES', '028', 'BA', 'B', 'NBR028', 'Backroom'),
(13, 'ATM 1 Thermal/ Heat', 'NBA013', 'YES', '013', 'BA', 'R', 'NBR013', ''),
(14, 'ATM 2 Thermal/ Heat', 'NBA014', 'YES', '014', 'BA', 'R', 'NBR014', ''),
(15, 'Chest Door Open ATM1', 'NBA015', 'YES', '015', 'BA', 'R', 'NBR015', 'Lobby Cam'),
(16, 'Chest Door Open ATM2', 'NBA016', 'YES', '016', 'BA', 'R', 'NBR016', 'Lobby Cam'),
(17, 'Chest Door Open ATM3', 'NBA017', 'YES', '017', 'BA', 'R', 'NBR017', 'Lobby Cam'),
(18, 'AC /UPS removal', 'NBA018', 'YES', '018', 'BA', 'B', 'NBR018', 'BackRoom Cam'),
(19, 'Cheque drop box removal', 'NBA019', 'YES', '019', 'BA', 'B', 'NBR019', 'Lobby Cam'),
(20, 'Cheque drop box open', 'NBA020', 'YES', '020', 'BA', 'B', 'NBR020', 'Lobby Cam'),
(21, 'CCTV 1+2+3 Removal', 'NBA021', 'YES', '021', 'BA', 'R', 'NBR021', 'Lobby Cam + Back room Cam'),
(22, 'ATM 3 Thermal/ Heat', 'NBA022', 'YES', '022', 'BA', 'R', 'NBR022', ''),
(23, 'Backroom Door Open', 'NBA023', 'YES', '023', 'BA', 'R', 'NBR023', 'BackRoom Cam'),
(24, 'Lobby Temprature Sensor High', 'NBA024', 'YES', '024', 'BA', 'B', 'NBR024', 'Lobby Cam'),
(25, 'ATM 1/2 Hood Door Sensor', 'NBA025', 'YES', '025', 'BA', 'R', 'NBR025', 'Lobby Cam'),
(26, 'Lobby Temprature Sensor Low', 'NBA026', 'YES', '026', 'BA', 'Y', 'NBR026', 'Lobby Cam'),
(27, 'Silence Key', 'NTA027', 'YES', '027', 'TA', 'Y', 'NTR027', 'Lobby Cam'),
(28, 'Speaker / MIC Removal', 'NBA012', 'YES', '012', 'BA', 'R', 'NBR012', 'Lobby Cam'),
(29, 'AC Mains Fail DI', 'NAT029', 'NO', '029', 'AT', 'B', 'NAR029', 'BackRoom Cam'),
(30, 'UPS O/P Fail DI', 'NAT030', 'YES', '030', 'AT', 'B', 'NAR030', 'BackRoom Cam'),
(31, 'Panel Tamper Switch', 'NTA034', 'YES', '034', 'TA', 'Y', 'NTR034', 'BackRoom Cam'),
(32, 'Low Battery', 'NYT998', 'YES', '998', 'YT', 'Y', 'YR998', ''),
(33, 'No battery', 'NYT997', 'YES', '997', 'YT', 'B', 'YR997', ''),
(34, 'Fire Trouble Smoke sense', 'NFT996', 'YES', '996', 'FT', 'R', 'FZ996', 'Lobby Cam'),
(35, 'Backroom Door Open', 'NCL001', '', '001', 'CL', 'Y', '', 'BackRoom Cam'),
(36, 'Backroom Door Open', 'NOA001', '', '001', 'OA', 'Y', '', 'BackRoom Cam'),
(37, 'Backroom Door Open', 'NOA002', 'YES', '002', 'OA', 'Y', '', 'BackRoom Cam'),
(38, 'Backroom Door Open', 'NOA003', '', '003', 'OA', 'Y', '', 'BackRoom Cam'),
(39, 'Backroom Door Open', 'NOA004', '', '004', 'OA', 'Y', '', 'BackRoom Cam'),
(40, 'HEARTBEAT', '', '', '', '', 'B', '', ''),
(41, 'Acknowledged massage from server', 'ACK', '', '', 'ACK', 'B', '', ''),
(42, 'Backroom Door Open', 'NOA005', NULL, '005', 'OA', 'Y', NULL, 'BackRoom Cam'),
(43, 'Backroom Door Open', 'NOA006', NULL, '006', 'OA', 'Y', NULL, 'BackRoom Cam'),
(44, 'Backroom Door Open', 'NOA007', NULL, '007', 'OA', 'Y', NULL, 'BackRoom Cam'),
(45, 'Backroom Door Open', 'NOA008', NULL, '008', 'OA', 'Y', NULL, 'BackRoom Cam'),
(46, 'Backroom Door Open', 'NOA009', NULL, '009', 'OA', 'Y', NULL, 'BackRoom Cam'),
(47, 'Backroom Door Open', 'NOA010', NULL, '010', 'OA', 'Y', NULL, 'BackRoom Cam'),
(48, 'Backroom Door Open', 'NOA011', NULL, '011', 'OA', 'Y', NULL, 'BackRoom Cam'),
(49, 'Backroom Door Open', 'NOA012', NULL, '012', 'OA', 'Y', NULL, 'BackRoom Cam'),
(50, 'Backroom Door Open', 'NOA013', NULL, '013', 'OA', 'Y', NULL, 'BackRoom Cam'),
(51, 'Backroom Door Open', 'NOA014', NULL, '014', 'OA', 'Y', NULL, 'BackRoom Cam'),
(52, 'Backroom Door Open', 'NOA015', NULL, '015', 'OA', 'Y', NULL, 'BackRoom Cam'),
(53, 'Backroom Door Open', 'NOA016', NULL, '016', 'OA', 'Y', NULL, 'BackRoom Cam'),
(54, 'Backroom Door Open', 'NOA017', NULL, '017', 'OA', 'Y', NULL, 'BackRoom Cam'),
(55, 'Backroom Door Open', 'NOA018', NULL, '018', 'OA', 'Y', NULL, 'BackRoom Cam'),
(56, 'Backroom Door Open', 'NOA019', NULL, '019', 'OA', 'Y', NULL, 'BackRoom Cam'),
(57, 'Backroom Door Open', 'NOA020', NULL, '020', 'OA', 'Y', NULL, 'BackRoom Cam'),
(58, 'Network Alarm', 'NBA077', NULL, '077', 'BA', 'Y', 'NBR077', 'BackRoom Cam'),
(59, 'Hooter On Locally', '881', NULL, '881', 'LE', 'Y', 'LF', 'LOBBY'),
(60, 'Backroom Door Open', 'NOA000', NULL, '000', 'OA', 'Y', NULL, 'BackRoom Cam');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
