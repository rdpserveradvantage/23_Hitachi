/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 10.4.21-MariaDB 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `all_states` (
	`state_code` text ,
	`state_name` text ,
	`country_code` text 
); 
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('1','Andaman & Nicobar [AN]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('2','Andhra Pradesh[AP]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('3','Arunachal Pradesh [AR]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('4','Assam [AS]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('5','Bihar [BH]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('6','Chandigarh [CH]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('7','Chhattisgarh [CG]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('8','Dadra & Nagar Haveli [DN]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('9','Daman & Diu [DD]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('10','Delhi [DL]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('11','Goa [GO]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('12','Gujarat [GU]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('13','Haryana [HR]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('14','Himachal Pradesh [HP]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('15','Jammu & Kashmir [JK]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('16','Jharkhand [JH]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('17','Karnataka [KR]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('18','Kerala [KL]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('19','Lakshadweep [LD]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('20','Madhya Pradesh [MP]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('21','Maharashtra [MH]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('22','Manipur [MN]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('23','Meghalaya [ML]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('24','Mizoram [MM]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('25','Nagaland [NL]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('26','Orissa [OR]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('27','Pondicherry [PC]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('28','Punjab [PJ]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('29','Rajasthan [RJ]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('30','Sikkim [SK]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('31','Tamil Nadu [TN]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('32','Telangana [TL]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('33','Tripura [TR]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('34','Uttar Pradesh [UP]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('35','Uttaranchal [UT]','+91');
insert into `all_states` (`state_code`, `state_name`, `country_code`) values('36','West Bengal [WB]','+91');
