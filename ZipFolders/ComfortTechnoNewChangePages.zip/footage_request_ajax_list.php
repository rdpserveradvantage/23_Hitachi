<?php session_start();include('db_connection.php'); ?>
<?php 

$client = $_GET['client'];
$banks = explode(",",$_SESSION['bankname']);
       $_bank_name = [];
       for($i=0;$i<count($banks);$i++){
		   $_bank = explode("_",$banks[$i]);
		   if($_bank[0]==$client){
			   array_push($_bank_name,$_bank[1]);
		   }
	   } 
	    $_bank_name=json_encode($_bank_name);
		$_bank_name=str_replace( array('[',']','"') , ''  , $_bank_name);
		$bankarr=explode(',',$_bank_name);
		$_bank_name = "'" . implode ( "', '", $bankarr )."'";

   $bank = "";
   $atmid = "";
if(isset($_GET['bank'])){
$bank = $_GET['bank'];
}
if(isset($_GET['atmid'])){
$atmid = $_GET['atmid'];
}
$user = $_GET['user'];
$status = $_GET['Status'];
$con = OpenCon();

if($atmid!=''){
	if($status=='all'){
$sql = mysqli_query($con,"select * from footage_request where atmid='".$atmid."' order by id desc"); 		
	}else{
$sql = mysqli_query($con,"select * from footage_request where atmid='".$atmid."' and status='".$status."' order by id desc"); 
	}

}else{
	if($bank!=''){
	  $sitesql = mysqli_query($con,"select ATMID from sites where Customer='".$client."' and Bank='".$bank."' and live='Y'");
	}else{
		$sitesql = mysqli_query($con,"select ATMID from sites where Customer='".$client."' and Bank IN (".$_bank_name.") and live='Y'");
	}
	//$atmidarray = [];
	while($sitesql_result = mysqli_fetch_assoc($sitesql)){
		$atmidarray[] = $sitesql_result['ATMID'];
		//array_push($atmidarray,(string)$atmid);
	}
	$atmidarray=json_encode($atmidarray);
	$atmidarray=str_replace( array('[',']','"') , ''  , $atmidarray);
	$arr=explode(',',$atmidarray);
	$atmidarray = "'" . implode ( "', '", $arr )."'";
	if($status=='all'){
		$onlinetestsql = "SELECT * FROM footage_request WHERE atmid IN (".$atmidarray.") order by id desc";
	}else{
	    $onlinetestsql = "SELECT * FROM footage_request WHERE atmid IN (".$atmidarray.") and status='".$status."' order by id desc";
	}
    $sql = mysqli_query($con,$onlinetestsql);
}

?>


<div class="table-responsive">
                    <table id="order-listing" class="table">
                      <thead>
                        <tr>
							<th>ATMID</th>
                            <th>Card No.</th>
                            <th>Date of Transaction</th>
                            <th>Time of Transaction</th>
                            <th>Nature of Transaction</th>
                            <th>Amount of Transaction</th>
                            <th>Transaction No.</th>
                            <th>Complaint No.</th>
                            <th>Complaint Date</th>
                            <th>Claim Date</th> 
                            <th>Action</th> 
													  
						</tr>
                      </thead>
                      <tbody>
					    <?php 
                        $count = 1 ; 
						  if(mysqli_num_rows($sql)>0){
							  while($sql_result = mysqli_fetch_assoc($sql)){
                                $_status = $sql_result['status'];
								$_id = $sql_result['id'];
                        ?>
							   <tr>
							        <td><?php echo $sql_result['atmid'];?></td>
								    <td><?php echo $sql_result['card_no'];?></td>
								    <td><?php echo $sql_result['date_of_TXN'];?></td>
								    <td><?php echo $sql_result['time_of_TXN'];?></td>
								    <td><?php echo $sql_result['nature_of_TXN'];?></td>
								    <td><?php echo $sql_result['amount_of_TXN'];?></td>
								    <td><?php echo $sql_result['txn_no'];?></td>
								    <td><?php echo $sql_result['complaint_no'];?></td>
								    <td><?php echo $sql_result['complaint_date'];?></td>
								    <td><?php echo $sql_result['claim_date'];?></td>
								    <td>
									<?php if($_status==0){ if($user=='comfort'){ ?> <a class="btn btn-info" href="footage_request_edit.php?id=<?php echo $_id;?>">Process</a> <?php } }?>
									<a class="btn btn-info" href="footage_request_details.php?id=<?php echo $_id;?>">View/Update Status</a>
									</td>
                  
								</tr>
								
						<?php }
						  }
						?>
                      </tbody>
                    </table>
                  </div>

<?php
CloseCon($con);

?>

