-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2021 at 06:32 AM
-- Server version: 10.3.31-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurv`
--

-- --------------------------------------------------------

--
-- Table structure for table `dvr_history`
--

CREATE TABLE `dvr_history` (
  `id` int(11) NOT NULL DEFAULT 0,
  `ip` varchar(15) CHARACTER SET utf8 NOT NULL,
  `status` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `cam1` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `cam2` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `cam3` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `cam4` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `hdd` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `latency` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
  `cdate` datetime NOT NULL,
  `login_status` int(11) NOT NULL COMMENT '0- ok , 1 - no',
  `last_communication` datetime NOT NULL,
  `atmid` varchar(15) NOT NULL,
  `capacity` varchar(25) NOT NULL,
  `freespace` varchar(25) NOT NULL,
  `recording_from` varchar(30) NOT NULL,
  `recording_to` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
