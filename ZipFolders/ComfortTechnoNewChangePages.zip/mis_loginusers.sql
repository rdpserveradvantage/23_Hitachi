-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 16, 2021 at 07:10 AM
-- Server version: 10.3.31-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurv`
--

-- --------------------------------------------------------

--
-- Table structure for table `loginusers`
--

CREATE TABLE `mis_loginusers` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `permission` varchar(200) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `level` varchar(191) NOT NULL,
  `cust_id` text NOT NULL,
  `currentstatus` int(11) NOT NULL DEFAULT 0 COMMENT '0-logout,1-login',
  `alerts` int(11) NOT NULL DEFAULT 0,
  `branch` varchar(200) NOT NULL,
  `zone` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mis_loginusers`
--

INSERT INTO `mis_loginusers` (`id`, `name`, `uname`, `pwd`, `permission`, `designation`, `level`, `cust_id`, `currentstatus`, `alerts`, `branch`, `zone`) VALUES
(24, 'admin', 'admin@gmail.com', 'Comfort@321321', '1,11,12,13,14,15,16,23,24,5,6,34,7,8,9,10', '1', '1', 'All', 0, 0, '0', ''),
(239, 'Lucknow Team', 'lucknow@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '34,20,36,17,41,18,26,44,27', 'North'),
(27, 'jay', 'jay@gmail.com', '1994', '5,6,7,8,9,10,31', '0', '1', 'All', 0, 0, '55,21,31,34,21', 'West,South,North'),
(28, 'sandeep', 'sandeep-backup@gmail.com', 'qwerty', '3,4,5,6,7,8,9,10', '3', '1', 'All', 0, 0, '8,22,11,12,30,33,35,32,38,45,46,54,,55,52,53,48,50,49', 'South,West'),
(31, 'RAJ', 'RAJ-backup@comforttechno.com', '1017', '5,6,7,8,10', '3', '1', 'All', 0, 0, '6,5,1,51,2,4,3', 'West'),
(33, 'mujju', 'mujju@gmail.com', '12345', '', '2', '1', 'All', 0, 0, '0', ''),
(79, 'rahulg', 'rahulg@gmail.com', '7666', '', '2', '1', 'All', 0, 0, '0', ''),
(186, 'SHUBHAM MISHRA', 'SHUBHAMMISHRA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '20', 'North'),
(139, 'Shubham', 'shubham@gmail.com', 'qwerty', '1,2,11,12,13,14,15,16,23,24,3,4,5,6,7,8,9,10,31', '3', '1', 'All', 0, 0, '16,10,19,28,34,20,42,36,61,15,9,17,37,31,41,43,25,18,13,26,44,40,27,23,21,8,29,55,50,11,30,2,46,53,4,1,51,32,49,45,38,6,33,12,35,22,5,52,3,54,48,checked', 'East,North,South,West'),
(152, 'Rahul B', 'rahuldbz8-backup@gmail.com', '12345', '5,6,7,8,10', '0', '1', 'All', 0, 0, '9', 'East,North'),
(153, 'sai', 'sai@gmail.com', 'ksai12', '', '2', '1', 'All', 0, 0, '0', ''),
(40, 'suraj', 'suraj@gmail.com', 'suraj123', '', '2', '1', 'All', 0, 0, '0', ''),
(92, 'shashikant', 'mshashi@gmail.com', 'aryashashi', '', '2', '1', 'All', 0, 0, '0', ''),
(157, 'helpdesk', 'helpdesk@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(43, 'sangita pal', 'sangita@gmail.com', '4444', '', '0', '1', 'All', 0, 0, '0', ''),
(44, 'karishma gupta', 'karishma@gmail.com', '4321', '5,6,9,10', '0', '1', 'All', 0, 0, '16,10,19,28,34,20,42,36,,15,9,17,37,31,41,43,25,18,13,26,44,40,27,23,21,8,29,55,50,11,30,2,46,53,4,1,51,32,49,45,38,6,33,12,35,22,5,52,3,54,48,', 'East,North,South,West'),
(50, 'irshad', 'irshad@gmail.com', '143', '', '0', '1', 'All', 0, 0, '0', ''),
(58, 'Ashish Dubey', 'ashish@gmail.com', 'qwerty', '7,8', '0', '1', 'All', 0, 0, '0', ''),
(60, 'shilpa', 'shilpa@gmail.com', '2225', '', '2', '1', 'All', 0, 0, '0', ''),
(140, 'sunny', 'sunny@gmail.com', '786', '', '2', '1', 'All', 0, 0, '0', ''),
(74, 'arun', 'arunch33@gmail.com', '@Run1231', '1,2,11,12,13,14,15,16,23,24,4,5,6,7,8,9,10', '3', '1', 'All', 0, 0, '0', ''),
(145, 'Sany', 'sany@gmail.com', 'sany', '', '2', '1', 'All', 0, 0, '0', ''),
(75, 'Rahul Tiwari', 'rahul-backup@comforttechno.com', '4432', '5,6,7,8,10', '3', '1', 'All', 0, 0, '16,10,19,28,34,20,42,36,61,15,9,17,37,31,41,43,25,18,13,26,44,40,27,23,21,8,29,55,50,11,30,2,46,53,4,1,51,32,49,45,38,6,33,12,35,22,5,52,3,54,48,', 'East,North,South,West'),
(76, 'mangesh', 'mangesh@gmail.com', '808080', '7,8', '2', '1', 'All', 0, 0, '0', ''),
(135, 'Muskan', 'Muskan@gmail.com', '43210', '', '2', '1', 'All', 0, 0, '0', ''),
(93, 'MDSAHIL', 'mdsahil@gmail.com', 'md123*', '5,6,7,8,25,9,10', '3', '1', 'All', 0, 0, '0', ''),
(94, 'HARISH', 'HARISH@gmail.com', 'harish', '', '2', '1', 'All', 0, 0, '0', ''),
(95, 'swapnil', 'swapnil@gmail.com', '0707', '', '2', '1', 'All', 0, 0, '0', ''),
(154, 'nikhil', 'nikhil@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(98, 'brijeshy', 'brijeshy@gmail.com', 'birju', '5,6,7,8,9,10', '3', '1', 'All', 0, 0, '0', ''),
(102, 'nishant', 'nishant@gmail.com', 'sharma', '5,6', '2', '1', 'All', 0, 0, '0', ''),
(103, 'jay', 'jay@gmail.com1', '1994', '', '0', '1', 'All', 0, 0, '0', ''),
(150, 'comfort', 'comfort@gmail.com', '1234', '', '2', '1', 'All', 0, 0, '0', ''),
(136, 'Krishna K', 'krishnak@gmail.com', '4321', '', '2', '1', 'All', 0, 0, '0', ''),
(170, 'Account', 'account@comforttechno.com', 'account@321#', '', '2', '5', 'All', 0, 0, '0', ''),
(112, 'ranjit', 'ranjit@gmail.com', 'ranjit', '', '2', '1', 'All', 0, 0, '0', ''),
(113, 'krishna', 'krishna@gmail.com', '0000', '', '2', '1', 'All', 0, 0, '0', ''),
(114, 'sushil', 'sushil@gmail.com', 'sushil', '', '2', '1', 'All', 0, 0, '0', ''),
(155, 'swati', 'swati@gmail.com', '1234', '', '2', '1', 'All', 0, 0, '0', ''),
(156, 'umesh', 'umesh@gmail.com', 'umesh', '', '2', '1', 'All', 0, 0, '0', ''),
(158, 'Julphkar', 'Julphkar@gmail.com', '6233', '', '2', '1', 'All', 0, 0, '0', ''),
(159, 'vikas', 'vikas@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(160, 'Amourya', 'Amourya@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(161, 'Aditya', 'Aditya@gmail.com', '3198', '', '2', '1', 'All', 0, 0, '0', ''),
(125, 'disu', 'disilva@gmail.com', 'disu', '', '2', '1', 'All', 0, 0, '0', ''),
(126, 'vikram', 'vikram@gmail.com', '9999', '', '2', '1', 'All', 0, 0, '0', ''),
(127, 'shweta', 'shweta@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(128, 'Ranjeet', 'Ranjeet@gmail.com', 'ranjeet', '', '2', '1', 'All', 0, 0, '0', ''),
(129, 'Harshita', 'Harshita@gmail.com', 'M@123', '', '2', '1', 'All', 0, 0, '0', ''),
(130, 'pradnya', 'pradnya@gmail.com', 'P@123', '', '2', '1', 'All', 0, 0, '0', ''),
(131, 'Mohan', 'Mohan@gmail.com', 'N@123', '', '2', '1', 'All', 0, 0, '0', ''),
(132, 'Satyashil', 'Satyashil@gmail.com', 'satya', '', '2', '1', 'All', 0, 0, '0', ''),
(133, 'humera', 'humera@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(134, 'preeti', 'preeti@gmail.com', 'P34A', '', '2', '1', 'All', 0, 0, '0', ''),
(141, 'Bhanu', 'Bhanu@gmail.com', '123456789', '7,8', '0', '1', 'All', 0, 0, '0', ''),
(143, 'shiv', 'shiv@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(144, 'vinay', 'vinay@gmail.com', '123', '', '2', '1', 'All', 0, 0, '0', ''),
(146, 'Rohit Bhardwaj', 'rohitb-backup@gmail.com', 'roh@9769', '5,6,7,8,10', '3', '1', 'All', 0, 0, '23,21,29', 'South'),
(148, 'sachin', 'sachin@gmail.com', '1234', '', '2', '1', 'All', 0, 0, '0', ''),
(162, 'Nitesh', 'Nitesh@gmail.com', '0000', '', '2', '1', 'All', 0, 0, '0', ''),
(163, 'sandip', 'sandip@gmail.com', 'sandy', '', '2', '1', 'All', 0, 0, '0', ''),
(164, 'wasim', 'wasim@gmail.com', 'Pass2649@', '5,6,7,8,9,10', '2', '1', 'All', 0, 0, '16,10,19,28,34,20,42,36,checked,15,9,17,37,31,41,43,25,18,13,26,44,40,27', 'East,North'),
(46, 'Rahul Kumar Mishra', 'rkmishra@gmail.com', 'Mishra', '1,2,11,12,13,14,15,16,23,24,3,4,5,6,34,7,8,9,10,31', '2', '2', 'Euronet,FSS,TATA,KOTAK,BajajFinance,Diebold,HITACHI,Writer,Comfort,SBI,Kores India LTD', 0, 0, '0', ''),
(142, 'Anand', 'anandm@comforttechno.com', '123789', '5,6,7,8,9,10', '2', '2', 'Diebold,HITACHI', 0, 0, '0', ''),
(167, 'sshaikh', 'sshaikh@comforttechno.com', 'sshaikh@123', '7,8,31', '2', '3', 'All', 0, 0, '0', ''),
(182, 'RUPANT PRAKASH', 'RUPANTPRAKASH@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '10', 'East'),
(168, 'ashish', 'ashish@comforttechno.com', 'ashish123*', '7,8,25,31', '2', '4', 'All', 0, 0, '0', ''),
(181, 'MUKESH KUMAR', 'MUKESHKUMAR@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '10', 'East'),
(169, 'Ravi Dubey', 'ravi@gmail.com', 'css1999', '5,6,7,8,9,10', '2', '1', 'All', 0, 0, '0', ''),
(171, 'Madhuri', 'madhuri@comforttechno.com', 'account@321#', '19,27,31', '2', '6', 'All', 0, 0, '0', ''),
(172, 'Neeta', 'neeta@comforttechno.com', 'account@321#', '8,22,21,20,28', '2', '7', 'All', 0, 0, '0', ''),
(180, 'SURAJ KUMAR', 'surajkumar@cts', 'cts@123', '4,5,6,9,10', '', '', '', 0, 0, '', ''),
(173, 'Pooja', 'pooja@comforttechno.com', 'account@321#', '8,22,20,29,31,32', '2', '8', 'All', 0, 0, '0', ''),
(179, 'Amit Raj', 'amitraj@cts.com', 'cts@123', '4,5,6,9,10', '', '', '', 0, 0, '10', 'East'),
(184, 'AMAN KUMAR', 'AMANKUMAR@CTS', 'cts123', '4,9,10', '', '', '', 0, 0, '', ''),
(241, 'Somnath', 'somnath@comforttechno.com', '123456', '31,32', '', '', '', 0, 0, '', ''),
(185, 'SONU KUMAR', 'SONUKUMAR@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '34,36', 'North'),
(183, 'SHUSHANT KUMAR', 'SHUSHANTKUMAR@CTS', 'CTS123', '4,5,6,9,10', '', '', '', 0, 0, '10', 'East'),
(254, 'Ashish Maurya', 'amaurya@gmail.com', 'cts12345', '3,4,5,6,34,7,9,10', '', '', '', 0, 0, '', ''),
(174, 'aniruddh', 'aniruddhvishwa@gmail.com', '12345', '', '', '', '', 0, 0, '', ''),
(175, 'Bangalore Team', 'Bangalore@cts.com', 'cts@123', '3,4,5,6,7,8,9,10', '', '', '', 0, 0, '23', 'South'),
(176, 'Chennai Team', 'Chennai@cts.com', 'cts@123', '4,5,6,9,10', '', '', '', 0, 0, '21,29', 'South'),
(177, 'MNPR Team', 'MNPS@cts.com', 'cts@123', '4,9,10', '', '', '', 0, 0, '8', 'South'),
(178, 'Sharayu', 'sharayu@comforttechno.com', 'account@321#', '8,20,31', '2', '9', 'All', 0, 0, '', ''),
(187, 'ILYAS ALI SHAIKH', 'ILYASALI@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '16', 'East'),
(188, 'SACHIN PAL', 'SACHINPAL@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '15', 'North'),
(189, 'DHIRENDRA KUMAR', 'DHIRENDRAKUMAR@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '', ''),
(190, 'DHANANJAY KUMAR', 'DHANANJAYKUMAR@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '', ''),
(191, 'ATUL KUMAR MISHRA', 'ATULKUMARMISHRA@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '9', 'North'),
(192, 'MANISH KUMAR Sharma', 'MANISHKUMAR@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(193, 'Devraj', 'Devraj@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(194, 'AKASH KUMAR', 'AKASHKUMAR@cts', 'cts@123', '4,5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(195, 'LAL BABU', 'LALBABU@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(196, 'VIKRANT Pandey', 'VIKRANT@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(197, 'DEEPAK', 'DEEPAK@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '61,37', 'North'),
(198, 'SANTOSH KUMAR', 'SANTOSHKUMAR@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '9', 'North'),
(199, 'Ajay Saini', 'AjaySaini@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '42,checked,31,43,25,40', 'North'),
(200, 'VISHAL GUPTA', 'VISHALGUPTA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '28', 'East'),
(201, 'SUKESH KR ROY', 'SUKESHROY@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '28', 'East'),
(202, 'SHRAVAN KUMAR TIWARI', 'SHRAVANTIWARI@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '18', 'North'),
(203, 'AWADHESH KUMAR PANDEY', 'AWADHESHPANDEY@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '18', 'North'),
(204, 'SHAILESH SHARMA', 'SHAILESHSHARMA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '18', 'North'),
(205, 'LOKESH', 'LOKESH@cts', 'cts123', '9,10', '', '', '', 0, 0, '26', 'North'),
(206, 'RAHUL VISHWKARMA', 'RAHULVISHWKARMA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '27', 'North'),
(207, 'vijay', 'vijay@comforttechno.com', 'account@321#', '8,20,26,30,32', '2', '9', '', 0, 0, '', ''),
(208, 'MALLANAGOUDA SHESHANGOUNDA', 'MALLANAGOUDA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(209, 'ANUSHA D V', 'ANUSHA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(210, 'VENGADESH', 'VENGADESH@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(211, 'HAMID A SATTAR PATHAN', 'HAMID@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(212, 'ARUN KUMAR V', 'ARUNKUMAR@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(213, 'AKASH', 'AKASH@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '23', 'South'),
(214, 'VIKKI KHATRI', 'VIKKIKHATRI@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '2', 'West'),
(215, 'ABDUL MAJID', 'ABDULMAJID@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '21', 'South'),
(216, 'AROCKIA BOUNDONI LOURDHU RAJAN', 'AROCKIA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '21', 'South'),
(217, 'D. Sudarshan', 'Sudarshan@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '21', 'South'),
(218, 'AVINASH YADAV', 'AVINASHYADAV@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '4', 'West'),
(219, 'MUKESH GOUR', 'MUKESHGOUR@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '1', 'West'),
(220, 'VISHANU', 'VISHANU@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '51', 'West'),
(221, 'JITENDRA RAJU CHAUDHARI', 'JITENDRACHAUDHARI@cts', 'cts123', '4,9,10', '', '', '', 0, 0, '32', 'West'),
(222, 'SAGAR KELAPGAVADE', 'SAGARKELAPGAVADE@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '6', 'West'),
(223, 'KISHAN SAROJ', 'KISHANSAROJ@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '6', 'West'),
(224, 'RAHUL DUBEY', 'RAHULDUBEY@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '6', 'West'),
(225, 'PRASAD GAJANAN UTEKAR', 'PRASADUTEKAR@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '6', 'West'),
(226, 'MAHESH MAHENDRA KAMBLE', 'MAHESHKAMBLE@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '22', 'West'),
(227, 'ROSHAN PHALKE', 'ROSHANPHALKE@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '22', 'West'),
(228, 'SATISH SAMSON REDDY', 'SATISHREDDY@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '22', 'West'),
(231, 'sunil', 'sshinde@cssindia.in', 'sunil123*', '8,20', '2', '9', 'all', 0, 0, '', ''),
(230, 'NANA RAJENDRA THOMBARE', 'NANATHOMBARE@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '22', 'West'),
(232, 'ashish kamble', 'ashishk@comforttechno.com', '1234', '7,8', '0', '1', 'All', 0, 0, '', ''),
(233, 'Pune Team', 'pune@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '22', 'West'),
(234, 'LUDHIANA Team', 'LUDHIANA@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '13', 'North'),
(235, 'Ali sher', 'Alisher@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '13', ',North'),
(236, 'Subhash', 'Subhash@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '13', 'North'),
(237, 'Aman CHD', 'Amanchd@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '13', 'North'),
(238, 'Ali Raza', 'AliRaza@cts', 'cts123', '4,5,6,9,10', '', '', '', 0, 0, '13', 'North'),
(240, 'DELHI Offfice', 'saritac@cssindia.in', '123456', '4,5,6,7,8,25,9,10', '', '', '', 0, 0, '9,37', 'North'),
(242, 'Bikas', 'Bikas@comforttechno.com', 'bikas123*', '7,8', '', '1', 'All', 0, 0, '', ''),
(243, 'Bharat Pardeshi', 'Bharat@gmail.com', '9657765388', '3,4,5,6,9,10', '', '', '', 0, 0, '35', 'West'),
(244, 'Raja Raman', 'Rajaraman@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '10', 'East'),
(245, 'Suraj Singh', 'surajsingh@cts', 'cts321', '6,7,8', '', '', '', 0, 0, '', ''),
(246, 'Basudeo Das', 'Basudeodas@cts', 'cts321', '4,9,10', '', '', '', 0, 0, '19', 'East'),
(247, 'Saurabh chaubey', 'Saurabhchaubey@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '17', 'North'),
(248, 'Gomathi', 'gomathi@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '21', 'South'),
(249, 'Ajith', 'ajith@cts', 'cts@123', '5,6,9,10', '', '', '', 0, 0, '21', 'South'),
(250, 'Sunil Kumar', 'sunilkumar@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '18', 'North'),
(251, 'Ashwani shukla', 'Ashwani@cts', 'cts123', '5,6,9,10', '', '', '', 0, 0, '9', 'North'),
(252, 'Ashwani shukla', 'shuklabablu672@gmail.com', 'cts123', '', '', '', '', 0, 0, '', ''),
(253, 'P3ENKP13', '', '', '', '', '', '', 0, 0, '', ''),
(255, 'Testing', 'testing@gmail.com', '12345', '', '', '', '', 0, 0, '', ''),
(256, 'Rahul Bhardwaj', 'Rahulb@gmail.com', '12345', '3,4,5,6,7,8,9,10', '', '', '', 0, 0, '', ''),
(257, 'Rahul Tiwari 1', 'tiwari1@gmail.com', '12345', '3,4,5,6,7,8,9,10', '', '', '', 0, 0, '', ''),
(258, 'Ashish Mourya', 'mourya@gmail.com', '12345', '3,4,5,6,7,8,9,10', '', '', '', 0, 0, '', ''),
(259, 'Sandeep Prajapati', 'sprajapati@gmail.com', '12345', '3,4,5,6,7,8,9,10', '', '', '', 0, 0, '', ''),
(260, 'Rohit Bhardwaj', 'rohitb@gmail.com', '12345', '5,6,7,8,9,10', '', '', '', 0, 0, '', ''),
(261, 'OMKAR', 'omkar@comforttechno.com', 'omkar321*', '8,20,31', '2', '8', 'All', 0, 0, '', ''),
(262, 'Surendra Dubey', 'surendra@gmail.com', '12345', '7,8,9,10', '', '', '', 0, 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mis_loginusers`
--
ALTER TABLE `mis_loginusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uname` (`uname`),
  ADD KEY `id` (`id`),
  ADD KEY `designation` (`designation`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mis_loginusers`
--
ALTER TABLE `mis_loginusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
