<?php 
function getVideoClients($client){
    global $con;

	$sql = mysqli_query($con,"select Customer from sites where live='Y' group by Customer");
	
	$html = "";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Customer']; 
		$newhtml = '<option value="'.$value.'" '.if($client==$value){echo 'selected'}.'>'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getClients(){
    global $con;

	$sql = mysqli_query($con,"select Customer from sites where live='Y' group by Customer");
	
	$html = "";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Customer']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function get_Clients(){
    global $con;

	$sql = mysqli_query($con,"select Customer from sites where live='Y' group by Customer");
	
	$html = "";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Customer']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getBanks(){
    global $con;

	$sql = mysqli_query($con,"select Bank from sites where live='Y' group by Bank");
	
	$html = "<option value=''>Select</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Bank']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getBanksByClientID($client){
    global $con;
    $banks = explode(",",$_SESSION['bankname']);
	$sql = mysqli_query($con,"select Bank from sites where live='Y' and Customer='".$client."' group by Bank");
	
	$html = "<option value=''>Select</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Bank']; 
		$cust_bank = $client."_".$value;
		$newhtml = "";
		if(in_array($cust_bank,$banks)){
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		}
		$html .= $newhtml;
	}
	return $html;
}
function getBankAtmidList($client,$bank){
	global $con;

	$sql = mysqli_query($con,"select ATMID from sites where live='Y' and Customer='".$client."' and Bank='".$bank."'");
	
	$html = "<option value=''>All Site</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}
function getAtmids($bank){
    global $con;

	$sql = mysqli_query($con,"select ATMID from sites where live='Y' and Bank='".$bank."'");
	
	$html = "<option value=''>All Site</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getAtmidList($client,$bank){
    global $con;

	$sql = mysqli_query($con,"select ATMID from sites where live='Y' and Customer = '".$client."' and Bank='".$bank."'");
	
	$html = "<option value=''>All Site</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getCities($state_code)
{
	global $con;
	$sql=mysqli_query($con,"select * from all_cities where state_code = '" .trim($state_code)."'");
	// $state_name=mysqli_query($con,"select city_name from all_cities where ");
	$html='<option value="">Select</option>';
	while($sql_result = mysqli_fetch_assoc($sql))
	{
		$value = $sql_result['city_name']; 
		$city_code = $sql_result['city_code']; 

		$html .= '<option value="'.$city_code.'">'.$value.'</option>';
	}
	return json_encode($html);
}

function CityName($citycode)
{
	global $con;
	$sql=mysqli_query($con,"select * from all_cities where city_code = '" .trim($citycode)."'");
	
	$sql_result = mysqli_fetch_assoc($sql);
	
		return $sql_result['city_name']; 
}

function StateName($statecode)
{
	global $con;
	$sql=mysqli_query($con,"select * from all_states where state_code = '" .trim($statecode)."'");
	
	$sql_result = mysqli_fetch_assoc($sql);
	
		return $sql_result['state_name']; 
}
function getallalerttype($atmid){
	global $con;
    
	$sql = mysqli_query($con,"select Panel_Make from sites where ATMID='".$atmid."'");
	$sql_result = mysqli_fetch_assoc($sql);
    $panel_name = $sql_result['Panel_Make'];
	$paramater = 'SensorName';
	                        if($panel_name=='comfort'){
								$sql = mysqli_query($con,"select $paramater from comfort");
							}
							if($panel_name=='rass_boi'){
								$sql = mysqli_query($con,"select $paramater from rass_boi");
							}
							if($panel_name=='rass_pnb'){
								$sql = mysqli_query($con,"select $paramater from rass_pnb");
							}
							if($panel_name=='smarti_boi'){
								$sql = mysqli_query($con,"select $paramater from smarti_boi");
							}
							if($panel_name=='smarti_pnb'){
								$sql = mysqli_query($con,"select $paramater from smarti_pnb");
							}
							if($panel_name=='RASS'){
								$sql = mysqli_query($con,"select $paramater from rass where status=0");
							}
							if($panel_name=='rass_cloud'){
								$sql = mysqli_query($con,"select $paramater from rass_cloud where status=0");
							}
							if($panel_name=='rass_cloudnew'){
								$sql = mysqli_query($con,"select $paramater from rass_cloudnew where status=0");
							}
							if($panel_name=='rass_sbi'){
								$sql = mysqli_query($con,"select $paramater from rass_sbi where status=0");
							}
							if($panel_name=='SEC'){
								$sql = mysqli_query($con,"select $paramater from securico where status=0");
							}
							if($panel_name=='securico_gx4816'){
								$sql = mysqli_query($con,"select $paramater from securico_gx4816 where status=0");
							}
							if($panel_name=='sec_sbi'){
								$sql = mysqli_query($con,"select $paramater from sec_sbi where status=0");
							}
							if($panel_name=='Raxx'){
								$sql = mysqli_query($con,"select $paramater from raxx where status=0");
							}
							if($panel_name=='SMART -I'){
								$sql = mysqli_query($con,"select $paramater from smarti where status=0");
							}
							if($panel_name=='SMART-IN'){
								$sql = mysqli_query($con,"select $paramater from smartinew where status=0");
							}
	
	$html = "";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['SensorName']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
	//$sensor_sql_result = mysqli_fetch_assoc($rass_sql);
	//return json_encode($sensor_sql_result);
}

function getDvrOnlineAtmids($bank){
    global $con;

	$sql = mysqli_query($con,"select ATMID from dvronline where Status='Y' and Bank='".$bank."'");
	
	$html = "<option value=''>All Site</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
	}
	return $html;
}

function getDvrOnlineBanksByClientID($client){
    global $con;
    $banks = explode(",",$_SESSION['bankname']);
	$sql = mysqli_query($con,"select Bank from dvronline where customer='".$client."' and Status='Y'");
	$_bank_name = array();
	$html = "<option value=''>Select</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Bank']; 
		if(in_array($value,$_bank_name)){
			
		}else{
			$_bank_name[] = $value;
			$cust_bank = $client."_".$value;
			$newhtml = "";
			if(in_array($cust_bank,$banks)){
			$newhtml = '<option value="'.$value.'">'.$value.'</option>';
			} 
			//$newhtml = '<option value="'.$value.'">'.$value.'</option>';
			$html .= $newhtml;
		}
	}
	return $html;
}

function totalvideocount($atmid,$dt){
	$filecount = 0;
	$dir = "E:\\FTP_DATA\\HIKVISION\\share\\$atmid\\$dt";
	$myDirectory=opendir("E:\\FTP_DATA\\HIKVISION\\share\\$atmid\\$dt");
                                     // Gets each entry
	while(false !== ($entryName=readdir($myDirectory))) {
		  $dirArray[]=$entryName;
	}
	natcasesort($dirArray);
	foreach ($dirArray as $file) {
		if($file!="." && $file!=".."){
			if($file!="DVRWorkDirectory" ){
				$_filecount = 0;
				$fi = new FilesystemIterator("E:\\FTP_DATA\\HIKVISION\\share\\$atmid\\$dt\\$file", FilesystemIterator::SKIP_DOTS);
				$_filecount = iterator_count($fi);
				$filecount = $filecount + $_filecount;
			}
		}
	} 
    return $filecount;
  // return $dir; 
}

function getVideoAtmidList($client,$bank){
    global $con;
    
	$atmidlist = mysqli_query($con,"select ATMID from sites where Customer='".$client."' and Bank='".$bank."' and live='Y'");
	 $atmidlistarr = array();
		  if(mysqli_num_rows($atmidlist)>0){
			  while($atmid_data=mysqli_fetch_assoc($atmidlist)){
				 $clientatmid = $atmid_data['ATMID']; 
				 array_push($atmidlistarr,$clientatmid);
			  }
		  }
	$_bank_name = array();
	$html = "<option value=''>Select</option>";
	
	$path = 'E:\FTP_DATA\HIKVISION\share';

    $files = scandir($path);
    
	$todaydate = date('Y-m-d');
	$_todaydate = str_replace('-','_',$todaydate);
	$yesterdaydate = date('Y-m-d',strtotime("-1 days"));
	$_yesterdaydate = str_replace('-','_',$yesterdaydate);
	
	$atm_present_array = array();
    foreach ($files as $key => $value) {
        $allinfo = explode('_', $value);
        $atm = $allinfo[0];
        if(strlen($atm)>5){
				for($p=0;$p<count($atmidlistarr);$p++){
					if($atm==$atmidlistarr[$p]){
				       $atm_present_array[] = $atm;
					}
				}
        }
    }  
	//return json_encode($atm_present_array);
	if(count($atm_present_array)>0){
		for($i=0;$i<count($atm_present_array);$i++){
			 // $todaytotalcount = totalvideocount($atm_present_array[$i],$_todaydate);
					 $todaytotalcount = 1;
			  if($todaytotalcount>0){
				  $actualtotalcount = $todaytotalcount;
			  }else{
				  $yesterdaytotalcount = totalvideocount($atm_present_array[$i],$_yesterdaydate);
				  if($yesterdaytotalcount>0){
					$actualtotalcount = $yesterdaytotalcount;  
				  }else{
					$actualtotalcount = 0;  
				  }
			  }

              if($actualtotalcount>0){
				       $newhtml = '<option value="'.$atm_present_array[$i].'">'.$atm_present_array[$i].'</option>';
					   $html .= $newhtml;
			  }			  
		}
	}
	
	
	
	/*
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		if(in_array($value,$_bank_name)){
			
		}else{
			$_bank_name[] = $value;
			$cust_bank = $client."_".$value;
			$newhtml = "";
			if(in_array($cust_bank,$banks)){
			$newhtml = '<option value="'.$value.'">'.$value.'</option>';
			} 
			
			$html .= $newhtml;
		}
	} */
	return $html;
}
function getCirclesByBank($bankcircle){
    global $con;
    $banks = explode(",",$_SESSION['bankname']);
	$sql = mysqli_query($con,"select Circle from site_circle where Bank='".$bankcircle."' group by Circle");
	
	$html = "<option value=''>Select</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['Circle']; 
		if($value!=''){
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
		}
	}
	return $html;
}
function getAtmidCircleList($bank,$circle){
    global $con;

	$sql = mysqli_query($con,"select ATMID from site_circle where Bank='".$bank."' AND Circle='".$circle."'");
	$html = "<option value=''>All Site</option>";
	while($sql_result = mysqli_fetch_assoc($sql)){
		$value = $sql_result['ATMID']; 
		if($value!=''){
		$newhtml = '<option value="'.$value.'">'.$value.'</option>';
		$html .= $newhtml;
		}
	}
	$newhtml = '<option value="Hello">Hello/</option>';
	return $html;
}
