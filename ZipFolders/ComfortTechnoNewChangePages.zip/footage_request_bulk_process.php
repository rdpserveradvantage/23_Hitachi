<?php
session_start();
include('db_connection.php');

if(isset($_POST['submit'])){
		$userid = $_SESSION['userid']; 
		$con = OpenCon();
			$date = date('Y-m-d h:i:s a', time());
			$only_date = date('Y-m-d');
			$target_dir = 'PHPExcel/';
			$file_name=$_FILES["images"]["name"];
			$file_tmp=$_FILES["images"]["tmp_name"];
			$file =  $target_dir.'/'.$file_name;


		$status ='open';                      
		$created_by = $_SESSION['userid'];
		$created_at = date('Y-m-d H:i:s');




			move_uploaded_file($file_tmp=$_FILES["images"]["tmp_name"],$target_dir.'/'.$file_name);
			include('PHPExcel/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php');
			$inputFileName = $file;

		  try {
			$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objPHPExcel = $objReader->load($inputFileName);
		  } catch (Exception $e) {
			die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . 
				$e->getMessage());
		  }

		  $sheet = $objPHPExcel->getSheet(0);
		  $highestRow = $sheet->getHighestRow();
		  $highestColumn = $sheet->getHighestColumn();

		  for ($row = 1; $row <= $highestRow; $row++) { 
			$rowData[] = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, 
											null, true, false);
										
		  }

		$row = $row-2;
		$error = '0';
		$contents='';
		
			for($i = 1; $i<=$row; $i++){
				
			  $atmid = $rowData[$i][0][0];
			  echo $atmid;
			  echo '<pre>';print_r($rowData[$i]);echo '</pre>';die;
				if($atmid){
					$sql = mysqli_query($con,"select * from sites where ATMID like '".$atmid."'");
				
				
					$call_receive = $rowData[$i][0][7];
					$component = $rowData[$i][0][8];
					$subcomponent =$rowData[$i][0][9];
					$docket_number =$rowData[$i][0][10];
					$remarks =$rowData[$i][0][11];
				 
		$amount = 'NULL';
				 
				 
				
				if($sql_result = mysqli_fetch_assoc($sql)){
					$customer = strtoupper($sql_result['Customer']);
					$bank = $sql_result['Bank'];
					$location = $sql_result['SiteAddress'];
					$city = $sql_result['City'];
					$state = $sql_result['State'];
					$zone = $sql_result['Zone'];
				}else{
					$bank =$rowData[$i][0][1];
					$customer =$rowData[$i][0][2];
					$zone = $rowData[$i][0][3];
					$city = $rowData[$i][0][4];
					$state = $rowData[$i][0][5];
					$location = $rowData[$i][0][6];            
				}

		$atmid = $_POST['atmid'];
		$cardno = $_POST['cardno'];
		$dateoftxn = $_POST['dateoftxn'];
		$timeoftxn = $_POST['timeoftxn'];
		$newTime = date("H:i", strtotime("$timeoftxn"));
			// echo $newTime; die;
		$natureoftxn = $_POST['natureoftxn']; 
		$amountoftxn = $_POST['amountoftxn'];
		$txnnumber = $_POST['txnnumber'];
		$complaint_no = $_POST['complaint_no'];
		$complaint_date = $_POST['complaint_date'];
		$claim_date = $_POST['claim_date'];
		$created_at = date('Y-m-d');
		$updated_at = date('Y-m-d');
	
	$statement = " INSERT INTO `footage_request`( `atmid`, `card_no`, `date_of_TXN`, `time_of_TXN`, `nature_of_TXN`, `amount_of_TXN`, `txn_no`, `complaint_no`, `complaint_date`, `claim_date`, `created_at`, `updated_at`) VALUES ('".$atmid."','".$cardno."','".$dateoftxn."','".$newTime."','".$natureoftxn."','".$amountoftxn."','".$txnnumber."','".$complaint_no."','".$complaint_date."','".$claim_date."','".$created_at."','".$updated_at."') ";
	 if(mysqli_query($con,$statement)){
				echo 'record created for ATMID' . $atmid ; 
				echo '<br>';
			}
			
		}

	}
	CloseCon($con);
	echo '<script>alert("Data Inserted")</script>';
    echo '<script>window.location="footage_request_bulk_upload.php"</script>';
}
else{ ?>

    <script>
    debugger;
        alert("Something Wrong");
        window.location.href="footage_request.php";

    </script>
<?php }

?>