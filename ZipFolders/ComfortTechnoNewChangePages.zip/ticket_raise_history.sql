-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 11, 2021 at 08:02 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esurv`
--

-- --------------------------------------------------------

--
-- Table structure for table `ticket_raise_history`
--

DROP TABLE IF EXISTS `ticket_raise_history`;
CREATE TABLE IF NOT EXISTS `ticket_raise_history` (
  `id` int(11) NOT NULL,
  `ticket_raise_id` int(11) DEFAULT NULL,
  `ticket_id` varchar(50) DEFAULT NULL,
  `client` varchar(100) DEFAULT NULL,
  `created_by` varchar(155) DEFAULT NULL,
  `ticket_status` int(11) DEFAULT NULL COMMENT '0=close, 1=active',
  `created_date` datetime DEFAULT NULL,
  `updated_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `close_date` datetime DEFAULT NULL,
  `location` varchar(155) DEFAULT NULL,
  `atmid` varchar(155) DEFAULT NULL,
  `alert_type` varchar(255) DEFAULT NULL,
  `dvr_ip` varchar(155) DEFAULT NULL,
  `alarm_type` varchar(70) DEFAULT NULL,
  `remarks` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
